NUMBER of locations in this datafile e.g. 2
LOCATION - Location Name --------------------------- NEW LOCATION 1
LOCATION - Street Number and Street Name  
LOCATION - County
LOCATION - PostCode
LOCATION - Latitude
LOCATION - Longitude
LOCATION - Number of years in dataset e.g. TWO YEARS
YEAR - description --------------------------------------------------- This is a new year = 2015 for location 1
YEAR - year Id - e.g 2015 
MONTH 1 - Month ID Number - e.g. 1
MONTH 1 - Maximum Temperature
MONTH 1 - Minimum Temperature
MONTH 1 - Number of Days of Air Frost
MONTH 1 - Millimetres of rainfall that month
MONTH 1 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 2 - Month ID Number - e.g. 2
MONTH 2 - Maximum Temperature
MONTH 2 - Minimum Temperature
MONTH 2 - Number of Days of Air Frost
MONTH 2 - Millimetres of rainfall that month
MONTH 2 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2015
MONTH 3 - Month ID Number - e.g. 3
MONTH 3 - Maximum Temperature
MONTH 3 - Minimum Temperature
MONTH 3 - Number of Days of Air Frost
MONTH 3 - Millimetres of rainfall that month
MONTH 3 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 4 - Month ID Number - e.g. 4
MONTH 4 - Maximum Temperature
MONTH 4 - Minimum Temperature
MONTH 4 - Number of Days of Air Frost
MONTH 4 - Millimetres of rainfall that month
MONTH 4 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 5 - Month ID Number - e.g. 5
MONTH 5 - Maximum Temperature
MONTH 5 - Minimum Temperature
MONTH 5 - Number of Days of Air Frost
MONTH 5 - Millimetres of rainfall that month
MONTH 5 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 6 - Month ID Number - e.g. 6
MONTH 6 - Maximum Temperature
MONTH 6 - Minimum Temperature
MONTH 6 - Number of Days of Air Frost
MONTH 6 - Millimetres of rainfall that month
MONTH 6 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2015
MONTH 7 - Month ID Number - e.g. 7
MONTH 7 - Maximum Temperature
MONTH 7 - Minimum Temperature
MONTH 7 - Number of Days of Air Frost
MONTH 7 - Millimetres of rainfall that month
MONTH 7 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 8 - Month ID Number - e.g. 8
MONTH 8 - Maximum Temperature
MONTH 8 - Minimum Temperature
MONTH 8 - Number of Days of Air Frost
MONTH 8 - Millimetres of rainfall that month
MONTH 8 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 9 - Month ID Number - e.g. 9
MONTH 9 - Maximum Temperature
MONTH 9 - Minimum Temperature
MONTH 9 - Number of Days of Air Frost
MONTH 9 - Millimetres of rainfall that month
MONTH 9 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 10 - Month ID Number - e.g. 10
MONTH 10 - Maximum Temperature
MONTH 10 - Minimum Temperature
MONTH 10 - Number of Days of Air Frost
MONTH 10 - Millimetres of rainfall that month
MONTH 10 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2015
MONTH 11 - Month ID Number - e.g. 11
MONTH 11 - Maximum Temperature
MONTH 11 - Minimum Temperature
MONTH 11 - Number of Days of Air Frost
MONTH 11 - Millimetres of rainfall that month
MONTH 11 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 12 - Month ID Number - e.g. 12
MONTH 12 - Maximum Temperature
MONTH 12 - Minimum Temperature
MONTH 12 - Number of Days of Air Frost
MONTH 12 - Millimetres of rainfall that month
MONTH 12 - Hours of sunshine that month
YEAR - description ------------------------------------------------ This is a new year = 2016 for location 1
YEAR - year Id - e.g 2016  
MONTH 1 - Month ID Number - e.g. 1
MONTH 1 - Maximum Temperature
MONTH 1 - Minimum Temperature
MONTH 1 - Number of Days of Air Frost
MONTH 1 - Millimetres of rainfall that month
MONTH 1 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 2 - Month ID Number - e.g. 2
MONTH 2 - Maximum Temperature
MONTH 2 - Minimum Temperature
MONTH 2 - Number of Days of Air Frost
MONTH 2 - Millimetres of rainfall that month
MONTH 2 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2016
MONTH 3 - Month ID Number - e.g. 3
MONTH 3 - Maximum Temperature
MONTH 3 - Minimum Temperature
MONTH 3 - Number of Days of Air Frost
MONTH 3 - Millimetres of rainfall that month
MONTH 3 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 4 - Month ID Number - e.g. 4
MONTH 4 - Maximum Temperature
MONTH 4 - Minimum Temperature
MONTH 4 - Number of Days of Air Frost
MONTH 4 - Millimetres of rainfall that month
MONTH 4 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 5 - Month ID Number - e.g. 5
MONTH 5 - Maximum Temperature
MONTH 5 - Minimum Temperature
MONTH 5 - Number of Days of Air Frost
MONTH 5 - Millimetres of rainfall that month
MONTH 5 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 6 - Month ID Number - e.g. 6
MONTH 6 - Maximum Temperature
MONTH 6 - Minimum Temperature
MONTH 6 - Number of Days of Air Frost
MONTH 6 - Millimetres of rainfall that month
MONTH 6 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2016
MONTH 7 - Month ID Number - e.g. 7
MONTH 7 - Maximum Temperature
MONTH 7 - Minimum Temperature
MONTH 7 - Number of Days of Air Frost
MONTH 7 - Millimetres of rainfall that month
MONTH 7 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 8 - Month ID Number - e.g. 8
MONTH 8 - Maximum Temperature
MONTH 8 - Minimum Temperature
MONTH 8 - Number of Days of Air Frost
MONTH 8 - Millimetres of rainfall that month
MONTH 8 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2015
MONTH 9 - Month ID Number - e.g. 9
MONTH 9 - Maximum Temperature
MONTH 9 - Minimum Temperature
MONTH 9 - Number of Days of Air Frost
MONTH 9 - Millimetres of rainfall that month
MONTH 9 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 10 - Month ID Number - e.g. 10
MONTH 10 - Maximum Temperature
MONTH 10 - Minimum Temperature
MONTH 10 - Number of Days of Air Frost
MONTH 10 - Millimetres of rainfall that month
MONTH 10 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2016
MONTH 11 - Month ID Number - e.g. 11
MONTH 11 - Maximum Temperature
MONTH 11 - Minimum Temperature
MONTH 11 - Number of Days of Air Frost
MONTH 11 - Millimetres of rainfall that month
MONTH 11 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2016
MONTH 12 - Month ID Number - e.g. 12
MONTH 12 - Maximum Temperature
MONTH 12 - Minimum Temperature
MONTH 12 - Number of Days of Air Frost
MONTH 12 - Millimetres of rainfall that month
MONTH 12 - Hours of sunshine that month
LOCATION - Location Name --------------------------- NEW LOCATION 2 ----------------------------------
LOCATION - Street Number and Street Name  
LOCATION - County
LOCATION - PostCode
LOCATION - Latitude
LOCATION - Longitude
LOCATION - Number of years in dataset e.g. ONE YEAR = 2017
YEAR - description --------------------------------------------------- This is the year for location 2
YEAR - year Id - e.g 2017
MONTH 1 - Month ID Number - e.g. 1
MONTH 1 - Maximum Temperature
MONTH 1 - Minimum Temperature
MONTH 1 - Number of Days of Air Frost
MONTH 1 - Millimetres of rainfall that month
MONTH 1 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 2 - Month ID Number - e.g. 2
MONTH 2 - Maximum Temperature
MONTH 2 - Minimum Temperature
MONTH 2 - Number of Days of Air Frost
MONTH 2 - Millimetres of rainfall that month
MONTH 2 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2017
MONTH 3 - Month ID Number - e.g. 3
MONTH 3 - Maximum Temperature
MONTH 3 - Minimum Temperature
MONTH 3 - Number of Days of Air Frost
MONTH 3 - Millimetres of rainfall that month
MONTH 3 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 4 - Month ID Number - e.g. 4
MONTH 4 - Maximum Temperature
MONTH 4 - Minimum Temperature
MONTH 4 - Number of Days of Air Frost
MONTH 4 - Millimetres of rainfall that month
MONTH 4 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 5 - Month ID Number - e.g. 5
MONTH 5 - Maximum Temperature
MONTH 5 - Minimum Temperature
MONTH 5 - Number of Days of Air Frost
MONTH 5 - Millimetres of rainfall that month
MONTH 5 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 6 - Month ID Number - e.g. 6
MONTH 6 - Maximum Temperature
MONTH 6 - Minimum Temperature
MONTH 6 - Number of Days of Air Frost
MONTH 6 - Millimetres of rainfall that month
MONTH 6 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2017
MONTH 7 - Month ID Number - e.g. 7
MONTH 7 - Maximum Temperature
MONTH 7 - Minimum Temperature
MONTH 7 - Number of Days of Air Frost
MONTH 7 - Millimetres of rainfall that month
MONTH 7 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 8 - Month ID Number - e.g. 8
MONTH 8 - Maximum Temperature
MONTH 8 - Minimum Temperature
MONTH 8 - Number of Days of Air Frost
MONTH 8 - Millimetres of rainfall that month
MONTH 8 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 9 - Month ID Number - e.g. 9
MONTH 9 - Maximum Temperature
MONTH 9 - Minimum Temperature
MONTH 9 - Number of Days of Air Frost
MONTH 9 - Millimetres of rainfall that month
MONTH 9 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 10 - Month ID Number - e.g. 10
MONTH 10 - Maximum Temperature
MONTH 10 - Minimum Temperature
MONTH 10 - Number of Days of Air Frost
MONTH 10 - Millimetres of rainfall that month
MONTH 10 - Hours of sunshine that month 
YEAR    - year Id repeated e.g. 2017
MONTH 11 - Month ID Number - e.g. 11
MONTH 11 - Maximum Temperature
MONTH 11 - Minimum Temperature
MONTH 11 - Number of Days of Air Frost
MONTH 11 - Millimetres of rainfall that month
MONTH 11 - Hours of sunshine that month
YEAR    - year Id repeated e.g. 2017
MONTH 12 - Month ID Number - e.g. 12
MONTH 12 - Maximum Temperature
MONTH 12 - Minimum Temperature
MONTH 12 - Number of Days of Air Frost
MONTH 12 - Millimetres of rainfall that month
MONTH 12 - Hours of sunshine that month
